require("dotenv").config();
const express = require("express");
const http = require("http");
const cors = require("cors");
const mysql = require("mysql2/promise");
const { Server } = require("socket.io");

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

// MySQL connection pool
const db = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

// GET /api/messages -> fetch chat history
app.get("/api/messages", async (req, res) => {
  try {
    const [rows] = await db.query("SELECT * FROM messages ORDER BY id ASC");
    res.json(rows);
  } catch (err) {
    console.log("Fetch error:", err.message);
    res.status(500).json({ error: "Could not fetch messages" });
  }
});

// POST /api/messages -> send a message
app.post("/api/messages", async (req, res) => {
  const { username, text } = req.body;

  if (!username || !text || !text.trim()) {
    return res.status(400).json({ error: "username and text are required" });
  }

  try {
    const [result] = await db.query(
      "INSERT INTO messages (username, text) VALUES (?, ?)",
      [username, text.trim()]
    );
    const [rows] = await db.query("SELECT * FROM messages WHERE id = ?", [result.insertId]);

    // broadcast the new message to all connected users
    io.emit("newMessage", rows[0]);

    res.status(201).json(rows[0]);
  } catch (err) {
    console.log("Send error:", err.message);
    res.status(500).json({ error: "Could not send message" });
  }
});

// Socket.io connection handling
io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);
  });

  socket.on("error", (err) => {
    console.log("Socket error:", err.message);
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
