import { useEffect, useRef, useState } from "react";
import { io } from "socket.io-client";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

function App() {
  const [username, setUsername] = useState(localStorage.getItem("username") || "");
  const [nameInput, setNameInput] = useState("");
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [error, setError] = useState("");
  const bottomRef = useRef(null);

  // load old messages + connect socket after login
  useEffect(() => {
    if (!username) return;

    fetch(`${API_URL}/api/messages`)
      .then((res) => res.json())
      .then((data) => setMessages(data))
      .catch(() => setError("Could not load messages"));

    const socket = io(API_URL);

    socket.on("newMessage", (msg) => {
      setMessages((prev) => [...prev, msg]);
    });
    socket.on("connect_error", () => setError("Cannot connect to server"));
    socket.on("connect", () => setError(""));

    return () => socket.disconnect();
  }, [username]);

  // scroll to latest message
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleLogin = (e) => {
    e.preventDefault();
    if (!nameInput.trim()) return;
    localStorage.setItem("username", nameInput.trim());
    setUsername(nameInput.trim());
  };

  const handleLogout = () => {
    localStorage.removeItem("username");
    setUsername("");
    setMessages([]);
  };

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;

    try {
      const res = await fetch(`${API_URL}/api/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, text }),
      });
      if (!res.ok) throw new Error();
      setText("");
      setError("");
    } catch {
      setError("Message failed to send");
    }
  };

  // login screen
  if (!username) {
    return (
      <div className="login">
        <form onSubmit={handleLogin}>
          <h2>Join Chat</h2>
          <input
            placeholder="Enter your username"
            value={nameInput}
            onChange={(e) => setNameInput(e.target.value)}
          />
          <button type="submit">Join</button>
        </form>
      </div>
    );
  }

  // chat screen
  return (
    <div className="chat">
      <div className="header">
        <span>Chat Room ({username})</span>
        <button onClick={handleLogout}>Logout</button>
      </div>

      {error && <div className="error">{error}</div>}

      <div className="messages">
        {messages.map((m) => (
          <div key={m.id} className={m.username === username ? "msg mine" : "msg"}>
            <b>{m.username}</b>
            <p>{m.text}</p>
            <small>{new Date(m.created_at).toLocaleString()}</small>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <form className="send" onSubmit={sendMessage}>
        <input
          placeholder="Type a message..."
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <button type="submit">Send</button>
      </form>
    </div>
  );
}

export default App;
