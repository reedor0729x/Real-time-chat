Chat App

A simple chat app made with React, Node.js, Express, Socket.io and MySQL. Users join with a username, send messages and see new messages instantly. Old messages are saved in MySQL and show again after refresh. Each message has a time.

Backend setup

Run the schema file to create the database and table. mysql -u root -p < backend/schema.sql
Go to the backend folder and install packages. cd backend npm install
Make a .env file in the backend folder. Copy from .env.example and add your MySQL password.
Start the server. It runs on http://localhost:8999 npm start

Frontend setup

Go to the frontend folder, install and run. cd frontend npm install npm run dev
Open the link shown in terminal (usually http://localhost:5173). Open two tabs with different usernames to test.

Environment variables (backend .env)

PORT, DB_HOST, DB_USER, DB_PASSWORD, DB_NAME

Optional in frontend: VITE_API_URL (default is http://localhost:8999)

APIs

GET /api/messages to get old messages. POST /api/messages to send a message (username and text).

Design decisions

I used React with Vite because it is easy. All backend code is in one file because the project is small. A message is saved in MySQL by the API and then sent to all users using Socket.io. Username is stored in localStorage as a simple login.

Assumptions

One chat room for everyone, no password, and usernames can repeat.